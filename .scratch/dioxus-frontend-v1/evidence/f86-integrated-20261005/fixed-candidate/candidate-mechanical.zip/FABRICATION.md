# Mechanical fabrication specification

Revision: 24
Process: printed
Mount system: tray
Plate finished thickness: 1.5 mm
PCB nominal thickness: 1.6 mm
Plate-to-PCB distance: 3.5 mm
Plate foam thickness: 3 mm
Bottom foam thickness: 2 mm
Wall thickness: 2 mm

The assembled STEP includes a nominal, unpopulated PCB reference. Component solids are not included. This reference is excluded from manufacturing part exports.

## Material and hardware

Material grade, finish and mechanical properties must be selected with the fabricator; no material grade is inferred from the process choice.
Plate mounting holes: auto-closure/mount-proposal-1: diameter 2.2 mm at (128.74750000000003, -112.01301492537313) mm; auto-closure/mount-proposal-63: diameter 2.2 mm at (-9.627062500000001, 10.121014925373132) mm; auto-closure/mount-proposal-55: diameter 2.2 mm at (103.41131250000001, -3.0318805970149327) mm; auto-closure/mount-proposal-22: diameter 2.2 mm at (23.504875000000006, -89.46519402985075) mm.
Hardware specifications (metadata only; threads are not modeled):
- No hardware specifications recorded.
Fastener compatibility, washers, inserts, torque, gasket material and adhesive specifications are not inferred from hole diameter. Review recorded hardware against the assembled stack before ordering.

Per-part process specifications:
- plate: printed; material PLA; finished thickness 1.5 mm; constraint set 2026-09-24
- plate-foam: cut-sheet; material EVA; finished thickness 3 mm; constraint set 2026-09-24
- bottom-foam: cut-sheet; material EVA; finished thickness 2 mm; constraint set 2026-09-24
- bottom: printed; material PLA; finished thickness 3 mm; constraint set 2026-09-24

## Critical fit and process allowances

Plate STEP, STL, SVG, DXF and KiCad geometry uses the same resolved millimetre design. Explicit radial opening allowance: 0 mm. Foam retains nominal exclusions. No automatic shrinkage, kerf or tool-radius compensation has been applied. Account for the recorded opening allowance before applying any additional reviewed CAM compensation; preserve the nominal source. CNC internal corners require a compatible tool radius or explicitly reviewed relief. Printed shrinkage and cut-sheet kerf require a measured process coupon. Critical interfaces: switch retention, stabilizer cutouts, plate-to-PCB distance, fastener fit and battery clearance. Confirm each before fabrication.

Recorded critical dimensions:
- No critical dimension annotations recorded.

Nominal opening extents (bounding dimensions, not replacement profiles):
- Opening 1: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 2: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 3: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 4: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 5: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 6: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 7: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 8: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 9: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 10: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 11: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 12: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 13: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 14: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 15: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 16: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 17: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 18: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 19: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 20: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 21: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 22: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 23: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 24: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 25: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 26: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 27: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.
- Opening 28: 18.357 × 18.357 mm; review the full contour for corner radii and retention tabs.
- Opening 29: 19.124 × 19.124 mm; review the full contour for corner radii and retention tabs.
- Opening 30: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.

Profile sources:
- No mechanical profiles configured.

Diagnostics:
- warning: No mounting points are configured; choose supported mounting locations before manufacturing.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.
- warning: Foam clearance uses the footprint courtyard as a conservative footprint approximation because no explicit mechanical clearance is assigned; a 3D model is not required.

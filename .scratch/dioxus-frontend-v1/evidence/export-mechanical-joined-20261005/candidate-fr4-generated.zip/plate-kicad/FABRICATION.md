# Mechanical plate

Revision: 1
Thickness: 1.5 mm

This is a separate mechanical plate, with no circuitry, copper tracks, vias or electrical nets. Edge.Cuts contains closed perimeter and switch cutouts. Mounting holes are non-plated through holes. Request no copper and no plated holes from the fabricator. Confirm material, finished thickness, machining tolerances and minimum cutout radii before ordering. Inspect generated Gerber and drill files in a CAM viewer and verify physical switch, stabilizer, PCB and enclosure fit. This project is not an electrical PCB export.

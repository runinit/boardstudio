# Mechanical fabrication specification

Revision: 1
Process: pcb-fr4
Mount system: rigid
Plate finished thickness: 1.5 mm
PCB nominal thickness: 1.6 mm
Plate-to-PCB distance: 3.5 mm
Plate foam thickness: 0 mm
Bottom foam thickness: 0 mm
Wall thickness: 2 mm

The assembled STEP includes a nominal, unpopulated PCB reference. Component solids are not included. This reference is excluded from manufacturing part exports.

## Material and hardware

Plate substrate: FR4, no copper or plated holes. Confirm grade, finish and thickness tolerance with the fabricator.
Plate mounting holes: mount: diameter 2.2 mm at (4, 4) mm; auto-closure/mount-proposal-1: diameter 2.2 mm at (9.260869565217392, 1) mm; auto-closure/mount-proposal-21: diameter 2.2 mm at (37.34782608695652, 25.888888888888896) mm; auto-closure/mount-proposal-22: diameter 2.2 mm at (5.956521739130436, 27.44444444444445) mm; auto-closure/mount-proposal-5: diameter 2.2 mm at (35.69565217391305, 1) mm.
Hardware specifications (metadata only; threads are not modeled):
- No hardware specifications recorded.
Fastener compatibility, washers, inserts, torque, gasket material and adhesive specifications are not inferred from hole diameter. Review recorded hardware against the assembled stack before ordering.

Per-part process specifications:
- No per-part overrides.

## Critical fit and process allowances

Plate STEP, STL, SVG, DXF and KiCad geometry uses the same resolved millimetre design. Explicit radial opening allowance: 0 mm. Foam retains nominal exclusions. No automatic shrinkage, kerf or tool-radius compensation has been applied. Account for the recorded opening allowance before applying any additional reviewed CAM compensation; preserve the nominal source. CNC internal corners require a compatible tool radius or explicitly reviewed relief. Printed shrinkage and cut-sheet kerf require a measured process coupon. Critical interfaces: switch retention, stabilizer cutouts, plate-to-PCB distance, fastener fit and battery clearance. Confirm each before fabrication.

Recorded critical dimensions:
- No critical dimension annotations recorded.

Nominal opening extents (bounding dimensions, not replacement profiles):
- Opening 1: 14.000 × 14.000 mm; review the full contour for corner radii and retention tabs.

Profile sources:
- No mechanical profiles configured.

Diagnostics:
- warning: Sharp internal rectangular corners require a reviewed routing radius; PCB process capability is not implied by a valid plate outline.
- warning: A sheet bottom without a middle frame leaves the assembly sides open.
- info: JLC PCB capability snapshot 2026-09-24: documented minimum NPTH 0.5 mm, non-plated slot 1.0 mm; slot tolerance ±0.2 mm. Supplier review is required for routing shape and stock selection.
